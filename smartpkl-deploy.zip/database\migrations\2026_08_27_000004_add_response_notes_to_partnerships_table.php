<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('school_company_partnerships', function (Blueprint $table) {
            $table->text('response_notes')->nullable()->after('notes');
        });
    }

    public function down(): void
    {
        Schema::table('school_company_partnerships', function (Blueprint $table) {
            $table->dropColumn('response_notes');
        });
    }
};
